# About

* folder web: speech to text
* folder game: control the game with speech
