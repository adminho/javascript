�ôԵ
https://www.google.com/intl/en/chrome/demos/speech.html
https://developer.mozilla.org/en-US/docs/Web/API/SpeechRecognition

