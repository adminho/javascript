�ôԵ
http://www.gaminglogy.com/tutorial/controls-keyboard/
https://developer.mozilla.org/en-US/docs/Web/API/SpeechRecognition
